// This running on lower version 8.2.2 gradle and warnning what version you running
// When working gradle keep crashing the app
// Some odd the manifestation work until the gradle work again corrector.

package com.example.fp211

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

// this set the content view to the activity_main layout.

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // To start the ConverterActivity, you need to create an Intent.
    // This will Start the ConverterActivity
    fun startConverter(view: View) {
        val intent = Intent(this, ConverterActivity::class.java)
        startActivity(intent)
    }

}
