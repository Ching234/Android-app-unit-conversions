package com.example.fp211

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ConverterActivity : AppCompatActivity() {

    private lateinit var editTextLength: EditText
    private lateinit var radioButtonMetersToCentimeters: RadioButton
    private lateinit var radioButtonCentimetersToMeters: RadioButton
    private lateinit var buttonConvert: Button
    private lateinit var buttonQuit: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_converter)

        // Initialize views
        editTextLength = findViewById(R.id.editTextLength)
        radioButtonMetersToCentimeters = findViewById(R.id.radioButtonMetersToCentimeters)
        radioButtonCentimetersToMeters = findViewById(R.id.radioButtonCentimetersToMeters)
        buttonConvert = findViewById(R.id.buttonConvert)
        buttonQuit = findViewById(R.id.buttonQuit)
        textViewResult = findViewById(R.id.textViewResult)
        // click for convert button
        buttonConvert.setOnClickListener {
            convertLength()
        }

        //  for quit button
        buttonQuit.setOnClickListener {
            finish()
        }
    }

    // Ask the user to enter length and return the text of the number that user enters
    // if the user don't eneter any length of the units into the programs
    private fun convertLength() {
        val lengthStr = editTextLength.text.toString()
        if (lengthStr.isEmpty()) {
            textViewResult.text = "Please enter a length in order to work"
            return
        }

        // The length represnt the number you enter the programs
        // this will go to result to convert the number user wanted
        // depend on the unit repsent string text base on the result
        // The button will switch base on the user inputs on units

        val length = lengthStr.toDouble()
        val result: Double
        val unit: String

        if (radioButtonMetersToCentimeters.isChecked) {
            result = convertMetersToCentimeters(length)
            unit = "Centimeters"
        } else if (radioButtonCentimetersToMeters.isChecked) {
            result = convertCentimetersToMeters(length)
            unit = "Meters"
        } else {
            // No conversion selected
            textViewResult.text = "Please select a conversion type"
            return
        }

        textViewResult.text = "Result: $result $unit"
    }

    private fun convertMetersToCentimeters(meters: Double): Double {
        return meters * 100
    }

    private fun convertCentimetersToMeters(centimeters: Double): Double {
        return centimeters / 100
    }
}
